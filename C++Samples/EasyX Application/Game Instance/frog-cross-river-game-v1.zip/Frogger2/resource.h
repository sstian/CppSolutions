//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by rcFile.rc
//
#define IDR_IMG_RC1                     121
#define IDR_IMG_RC2                     122
#define IDR_IMG_RC3                     123
#define IDR_IMG_RC4                     124
#define IDR_IMG_RC5                     125
#define IDR_IMG_RC6                     126

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        127
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
